
#include "threads/thread.h"
#include "threads/synch.h"
#include "projects/crossroads/blinker.h"

void init_blinker(struct blinker_info* blinkers, struct lock **map_locks, struct vehicle_info * vehicle_info) {

}

void start_blinker() {

}
