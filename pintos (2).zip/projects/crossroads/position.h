#ifndef __PROJECTS_PROJECT2_POSITION_H__
#define __PROJECTS_PROJECT2_POSITION_H__

struct position {
	int row;
	int col;
};

#endif